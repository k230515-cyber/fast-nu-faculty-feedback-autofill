const statusBox = document.getElementById('statusBox');
const statusText = document.getElementById('statusText');
const fillBtn = document.getElementById('fillBtn');
const fillOnlyBtn = document.getElementById('fillOnlyBtn');
const debugBtn = document.getElementById('debugBtn');
const debugOutput = document.getElementById('debugOutput');

function setStatus(type, msg) {
  statusBox.className = 'status-box ' + type;
  statusText.textContent = msg;
}

async function runScript(fn, args = []) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) { setStatus('error', 'No active tab found.'); return null; }
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: fn,
      args
    });
    return results?.[0]?.result;
  } catch (e) {
    setStatus('error', e.message);
    return null;
  }
}

// ── Debug scanner ─────────────────────────────────────────────────────────────
debugBtn.addEventListener('click', async () => {
  setStatus('running', 'Scanning page...');
  debugOutput.style.display = 'block';
  debugOutput.textContent = 'Scanning...';

  const result = await runScript(debugPage);
  if (!result) { debugOutput.textContent = 'Failed to scan page.'; return; }
  setStatus('', 'Scan done — share this info if still broken.');
  debugOutput.textContent = result;
});

function debugPage() {
  const radios = document.querySelectorAll('input[type="radio"]');
  const lines = [`Total radio inputs: ${radios.length}\n`];
  const names = new Set();

  radios.forEach((r, i) => {
    lines.push(`[${i}] name="${r.name}" value="${r.value}" checked=${r.checked} id="${r.id}"`);
    names.add(r.name);
  });

  lines.push(`\nGroups by name: ${[...names].join(' | ') || 'NONE'}`);

  const checks = [
    '[role="radio"]', '[class*="radio"]', '[class*="option"]',
    '[class*="choice"]', 'label input[type="radio"]'
  ];
  checks.forEach(sel => {
    const n = document.querySelectorAll(sel).length;
    if (n) lines.push(`Selector "${sel}": ${n} found`);
  });

  return lines.join('\n');
}

// ── Fill ──────────────────────────────────────────────────────────────────────
fillBtn.addEventListener('click', () => doFill(true));
fillOnlyBtn.addEventListener('click', () => doFill(false));

async function doFill(shouldSubmit) {
  setStatus('running', 'Filling form...');
  fillBtn.disabled = true;
  fillOnlyBtn.disabled = true;

  const scrollToBtn = document.getElementById('scrollToSubmit').checked;
  const result = await runScript(autoFillForm, [shouldSubmit, scrollToBtn]);

  if (!result) {
    setStatus('error', 'Script failed to run.');
  } else if (result.error) {
    setStatus('error', 'Error: ' + result.error);
  } else {
    const sub = result.submitted ? ' Submitted!' : shouldSubmit ? ' (no submit btn found)' : '';
    setStatus('success', `✓ Filled ${result.filled} question(s).${sub}`);
  }

  fillBtn.disabled = false;
  fillOnlyBtn.disabled = false;
}

// ── Injected page function ────────────────────────────────────────────────────
function autoFillForm(shouldSubmit, scrollToSubmitBtn) {
  try {

    // Framework-aware radio trigger
    function forceSelect(radio) {
      // 1. Native prototype setter (works with React)
      const descriptor = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'checked');
      if (descriptor && descriptor.set) {
        descriptor.set.call(radio, true);
      } else {
        radio.checked = true;
      }

      // 2. React internal tracker trick
      const tracker = radio._valueTracker;
      if (tracker) tracker.setValue('false'); // trick React into seeing a change

      // 3. Fire all relevant events
      radio.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      radio.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true, cancelable: true }));
      radio.dispatchEvent(new MouseEvent('click',     { bubbles: true, cancelable: true }));
      radio.dispatchEvent(new Event('input',  { bubbles: true }));
      radio.dispatchEvent(new Event('change', { bubbles: true }));
    }

    let filled = 0;
    const allRadios = Array.from(document.querySelectorAll('input[type="radio"]'));

    if (allRadios.length === 0) {
      // Try ARIA radios
      const ariaRadios = Array.from(document.querySelectorAll('[role="radio"]'));
      if (ariaRadios.length > 0) {
        const groups = {};
        ariaRadios.forEach(r => {
          const grp = r.closest('[role="radiogroup"]') || r.parentElement;
          const key = grp ? (grp.id || grp.className || grp.tagName) : 'x';
          if (!groups[key]) groups[key] = [];
          groups[key].push(r);
        });
        Object.values(groups).forEach(g => {
          g[0].click();
          g[0].setAttribute('aria-checked', 'true');
          g[0].dispatchEvent(new Event('change', { bubbles: true }));
          filled++;
        });
      }
      const sub = trySubmit(shouldSubmit, scrollToSubmitBtn);
      return { filled, submitted: sub };
    }

    // Group radios
    const byName = {};
    allRadios.forEach(r => {
      const key = r.name || '__noname__';
      if (!byName[key]) byName[key] = [];
      byName[key].push(r);
    });

    const groups = Object.values(byName);

    // If all radios share one name (or no names), group by DOM proximity instead
    const useProximity = groups.length === 1 && allRadios.length > 5;

    if (!useProximity) {
      // Named groups — first radio in each group
      groups.forEach(g => { forceSelect(g[0]); filled++; });
    } else {
      // Proximity grouping: find rows/containers
      const processed = new Set();
      allRadios.forEach(radio => {
        if (processed.has(radio)) return;
        let container = radio.parentElement;
        for (let depth = 0; depth < 8; depth++) {
          if (!container || container === document.body) break;
          const siblings = Array.from(container.querySelectorAll('input[type="radio"]'));
          if (siblings.length >= 2 && siblings.length <= 8) {
            forceSelect(siblings[0]);
            siblings.forEach(r => processed.add(r));
            filled++;
            break;
          }
          container = container.parentElement;
        }
      });
    }

    // If still nothing, try clicking labels
    if (filled === 0) {
      const labelGroups = {};
      document.querySelectorAll('label').forEach(label => {
        const forId = label.getAttribute('for');
        const input = forId
          ? document.getElementById(forId)
          : label.querySelector('input[type="radio"]');
        if (!input || input.type !== 'radio') return;
        const key = input.name || label.parentElement?.className || 'x';
        if (!labelGroups[key]) labelGroups[key] = [];
        labelGroups[key].push({ label, input });
      });
      Object.values(labelGroups).forEach(items => {
        forceSelect(items[0].input);
        items[0].label.click();
        filled++;
      });
    }

    const submitted = trySubmit(shouldSubmit, scrollToSubmitBtn);
    return { filled, submitted };

  } catch (e) {
    return { error: e.message };
  }

  function trySubmit(should, scroll) {
    if (!should) return false;
    const keywords = ['submit', 'save', 'finish', 'done', 'send', 'confirm', 'next'];
    const all = [...document.querySelectorAll('button, input[type="submit"]')];
    let btn = all.find(el => keywords.some(k =>
      (el.textContent || el.value || '').toLowerCase().includes(k)
    ));
    if (!btn) btn = document.querySelector('button[type="submit"], input[type="submit"]');
    if (!btn) return false;
    if (scroll) btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(() => btn.click(), 400);
    return true;
  }
}
